package com.nikon.model;

import java.sql.Date;

public class nikonsalesVO {
	private String scode;
	private String sid;
	private int sprice;
	private String splace;
	private String srecieve;
	
	
	public String getScode() {
		return scode;
	}
	public void setScode(String scode) {
		this.scode = scode;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public int getSprice() {
		return sprice;
	}
	public void setSprice(int sprice) {
		this.sprice = sprice;
	}
	public String getSplace() {
		return splace;
	}
	public void setSplace(String splace) {
		this.splace = splace;
	}
	public String getSrecieve() {
		return srecieve;
	}
	public void setSrecieve(String srecieve) {
		this.srecieve = srecieve;
	}
	
	
}
