package com.nikon.model;

public class nikonboxVO {

	private int  bno;
	private String bcom;
	private String baddr;
	private String btel;
	
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public String getBcom() {
		return bcom;
	}
	public void setBcom(String bcom) {
		this.bcom = bcom;
	}
	public String getBaddr() {
		return baddr;
	}
	public void setBaddr(String baddr) {
		this.baddr = baddr;
	}
	public String getBtel() {
		return btel;
	}
	public void setBtel(String btel) {
		this.btel = btel;
	}
	
}

